// Copyright (c) 2017 Object Computing, Inc.
// All rights reserved.
// See the file license.txt for licensing information.
#pragma once
#include <memory>
namespace orderentry
{
    class Order;
    typedef std::shared_ptr<Order> OrderPtr;
}
