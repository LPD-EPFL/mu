#pragma once

#include <fstream>
#include <vector>
#include "timers.h"

class ClientContext : public BasicAppContext {
 public:
  int index_ts;
  std::vector<TIMESTAMP_T> start_ts;
  std::vector<TIMESTAMP_T> end_ts;
  size_t req_size;  // Between kAppMinReqSize and kAppMaxReqSize
  uint64_t req_seq;
  erpc::Latency latency;
  erpc::MsgBuffer req_msgbuf, resp_msgbuf;
  ClientRequest req;
  int leader;

  bool first_change = true;
  bool under_change = false;
  TIMESTAMP_T change_start, change_end, last_req_ts, poll_ts;
  TIMESTAMP_T last_ok_req, prev_ok_req;
  int last_ok_leader, prev_ok_leader;

  ~ClientContext() {}
};

// Function declarations
void client_func(erpc::Nexus *nexus);
void connect_session(ClientContext &c);
inline void send_req(ClientContext &c);
void app_cont_func(void *_context, void *);

void client_func(erpc::Nexus *nexus) {
  std::vector<size_t> port_vec = flags_get_numa_ports(FLAGS_numa_node);
  uint8_t phy_port = port_vec.at(0);

  ClientContext c;
  c.index_ts = 0;
  c.start_ts.resize(2*MEDIAN_SAMPLE_SIZE);
  c.end_ts.resize(2*MEDIAN_SAMPLE_SIZE);

  auto &s = c.start_ts;
  auto &e = c.end_ts;

  std::memset(&s[0], 0, sizeof(s[0]) * s.size());
  std::memset(&e[0], 0, sizeof(e[0]) * e.size());

  c.rpc = new erpc::Rpc<erpc::CTransport>(
      nexus, static_cast<void *>(&c), kAppClientRpcId, basic_sm_handler, phy_port);
  c.rpc->retry_connect_on_invalid_rpc_id = true;

  c.req_size = sizeof(ClientRequest);
  c.req_seq = 0;

  c.req_msgbuf = c.rpc->alloc_msg_buffer_or_die(c.req_size);
  c.resp_msgbuf = c.rpc->alloc_msg_buffer_or_die(kAppRespSize);
  c.rpc->resize_msg_buffer(&c.req_msgbuf, c.req_size);
  c.rpc->resize_msg_buffer(&c.resp_msgbuf, kAppRespSize);

  connect_session(c);

  printf("Process %zu: Session connected. Starting work.\n", FLAGS_process_id);
  printf("write_size median_us 5th_us 99th_us 999th_us\n");

  send_req(c);

  int print_every = 1UL * 1000 * 1000 / kShortEvLoopUs;
  int print_index = print_every > 0 ? 1 : 0;

  while(true) {
    // c.rpc->run_event_loop(kAppEvLoopMs);
    c.rpc->run_event_loop_us(kShortEvLoopUs);
    GET_TIMESTAMP(c.poll_ts);

    if (ctrl_c_pressed == 1) break;


    print_index = (print_index + 1) % print_every;
    if (print_index == 0) {
      printf("%zu %.1f %.1f %.1f %.1f\n", c.req_size,
            c.latency.perc(.5) / kAppLatFac, c.latency.perc(.05) / kAppLatFac,
            c.latency.perc(.99) / kAppLatFac, c.latency.perc(.999) / kAppLatFac);

      c.latency.reset();
    }

    // if (!c.under_change && ELAPSED_NSEC(c.last_req_ts, c.poll_ts) > kChangeLeaderTimeoutUs) {
    //   c.under_change = true;
    //   c.leader = (c.leader % 2) + 1;
    // }

    auto elapsed = ELAPSED_NSEC(c.last_req_ts, c.poll_ts);
    if (elapsed > kChangeLeaderTimeoutNs) {
      // std::cout << "It has elapsed " << elapsed << " ns, req " << c.req_seq << std::endl;

      c.under_change = true;
      c.leader = (c.leader % 2) + 1;
      // std::cout << "It has elapsed " << elapsed << ", changing to leader " << c.leader << std::endl;

      send_req(c);
    }
  }
}

void connect_session(ClientContext &c) {
  int max_key = -1;
  for (std::pair<int, std::string> element : serverURIs) {
    if (max_key == -1) {
      c.leader = element.first;
    }

    max_key = std::max(max_key, element.first);
  }

  c.session_num_vec.resize(max_key + 1);

  // Create session to each server
  for (std::pair<int, std::string> element : serverURIs) {
    int i = element.first;
    auto &uri = element.second;
    printf("Creating session to %s, index = %d.\n", uri.c_str(), i);

    c.session_num_vec[i] = c.rpc->create_session(uri, kAppServerRpcId);
    if (c.session_num_vec[i] < 0) {
      throw std::runtime_error("Failed to create session.");
    }
  }

  while (c.num_sm_resps != serverURIs.size()) {
    c.rpc->run_event_loop(kAppEvLoopMs);
    if (unlikely(ctrl_c_pressed == 1)) return;
  }
}


inline void send_req(ClientContext &c) {
  GET_TIMESTAMP(c.last_req_ts);


  // Generate and insert the order into the message
  c.req_seq += 1;


  c.req.client_id = traderID;
  c.req.req_id = c.req_seq;
  c.req.is_buy = ((c.req_seq % 2) == 0);
  // c.req.is_buy = traderID == 0;
  uint32_t delta = c.req.is_buy ? 1880 : 1884;
  c.req.price = (rand() % 10) + delta;
  c.req.qty = ((rand() % 10) + 1) * 100;
  memcpy(c.req_msgbuf.buf, &c.req, c.req_size);


  c.rpc->enqueue_request(c.session_num_vec[c.leader], kAppReqType, &c.req_msgbuf,
                         &c.resp_msgbuf, app_cont_func, nullptr);
}

void app_cont_func(void *_context, void *) {
  auto *c = static_cast<ClientContext *>(_context);
  assert(c->resp_msgbuf.get_data_size() == kAppRespSize);

  auto resp = reinterpret_cast<ReplicationResponse *>(c->resp_msgbuf.buf);
  int prev_resp;
  double req_lat_us;

  switch (resp->kind) {
  case ReplicationResponse::OK:

      c->prev_ok_req = c->last_ok_req;
      c->prev_ok_leader = c->last_ok_leader;

      GET_TIMESTAMP(c->last_ok_req);

      req_lat_us = static_cast<double>(ELAPSED_NSEC(c->last_req_ts, c->last_ok_req) / 1000);
      c->latency.update(static_cast<size_t>(req_lat_us * kAppLatFac));

      c->last_ok_leader = resp->server_id;

      if (c->last_ok_leader != c->prev_ok_leader) {
        auto elapsed =  ELAPSED_NSEC(c->prev_ok_req, c->last_ok_req);
        std::cout << "Leader changed to " <<  c->last_ok_leader << ": " << elapsed / 1000 << " (us)" << std::endl;
      }

      c->under_change = false;

    // if ( (prev_resp = resp->cli_resp.num) > 0) {
    //   ClientResponse *cli_resp = reinterpret_cast<ClientResponse *>(uintptr_t(resp) + resp->cli_resp.offset);
    //   for (int i = 0; i < prev_resp; i++) {
    //     std::cout << "Req with ID " << cli_resp[i].req_id << " is filled! "
    //               << "Traded " <<  cli_resp[i].fill_qty << " stocks for "
    //               << cli_resp[i].fill_cost << std::endl;
    //   }
    // }

    // if (c->under_change) {
    //   GET_TIMESTAMP(c->change_end);

    //   auto elapsed =  ELAPSED_NSEC(c->change_start, c->change_end);
    //   std::cout << "Leader changed to " <<  c->leader << ": " << elapsed / 1000 << " (us)" << std::endl;

    //   c->first_change = true;
    //   c->under_change = false;
    // }
    break;

  case ReplicationResponse::CHANGE_LEADER:
    // if (c->first_change) {
    //   c->first_change = false;
    //   c->under_change = true;
    //   // GET_TIMESTAMP(c->change_start);
    // }
    c->under_change = true;
    // std::cout << "Instructed from leader: " << c->leader
    //           << " to change to leader: " << resp->v.potential_leader
    //           << std::endl;
    c->leader = resp->v.potential_leader;
    break;

  case ReplicationResponse::FATAL:
    std::cout << "Replication error: " << resp->v.fatal_error << std::endl;
    break;
  }

//   GET_TIMESTAMP(c->end_ts[c->index_ts]);
// #ifdef STORE_MEASUREMENTS
//   c->index_ts += 1;
// #endif

//   if (c->index_ts == MEDIAN_SAMPLE_SIZE) {
//     std::ofstream dump;
//     dump.open ("dump-cli.txt");

//     std::vector<uint64_t> diffs;
//     for (int i = 0; i < MEDIAN_SAMPLE_SIZE; i++) {
//       auto diff = ELAPSED_NSEC(c->start_ts[i], c->end_ts[i]);
//       dump << diff << "\n";
//     }

//     dump.close();
//     std::cout << "Dumped the data" << std::endl;
//     // exit(0);
//   }

  // std::this_thread::sleep_for(std::chrono::seconds(2));
  send_req(*c);
}

