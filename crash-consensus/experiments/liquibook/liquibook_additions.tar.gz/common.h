#pragma once

static int MEDIAN_SAMPLE_SIZE = 1000000;
#define STORE_MEASUREMENTS
#undef STORE_MEASUREMENTS

enum class OperationalMode {
  Server,
  Client
};

struct ClientRequest {
  int client_id;

  uint64_t req_id;
  bool is_buy;
  liquibook::book::Price price;
  liquibook::book::Quantity qty;
};

struct ClientResponse {
  uint64_t req_id;
  liquibook::book::Quantity fill_qty;
  liquibook::book::Cost fill_cost;
};

struct ClientResponses {
  int num;
  ptrdiff_t offset; // The offset where the replies start from the beginning of the replication Response
};

struct ReplicationResponse {
  enum Kind {
    OK,
    CHANGE_LEADER,
    FATAL
  };

  Kind kind;
  union {
    int commit_ret;
    int potential_leader;
    int fatal_error;
  } v;

  ClientResponses cli_resp;
};

template <size_t Alignment>
static constexpr size_t round_up_powerof2(size_t v) {
  return (v + Alignment - 1) & (-static_cast<ssize_t>(Alignment));
}

static constexpr uintptr_t cli_resp_offset = round_up_powerof2<16>(sizeof(ReplicationResponse));
static constexpr size_t kAppRespSize = cli_resp_offset + 8 * sizeof(ClientResponse);
static constexpr int max_num_cli_resp = (kAppRespSize - cli_resp_offset) / sizeof(ClientResponse);
