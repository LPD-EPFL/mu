#pragma once

// Function declarations
void server_func(erpc::Nexus *nexus);
void req_handler(erpc::ReqHandle *req_handle, void *_context);

class TraderContext {
public:
  TraderContext(orderentry::Market *market, orderentry::NamedOrderBook &namedBook) : market_(market), namedBook_(namedBook) {
  }

  bool placeOrder(uint64_t req_id, bool buy_otherwise_sell, liquibook::book::Quantity qty, liquibook::book::Price price) {
    return market_->placeOrder(namedBook_, notifier, req_id, buy_otherwise_sell, qty, price);
  }

  int previousResponsesNum() {
    return notifier.size();
  }

  int copyPreviousResponses(int num, ClientResponse *resp) {
    int i = 0;
    while (!notifier.empty() && num > 0) {
      auto &front = notifier.front();
      resp[i].req_id = front.order->req_id();
      resp[i].fill_qty = front.fill_qty;
      resp[i].fill_cost = front.fill_cost;

      // std::cout << *(notifier.front().order) << std::endl;

      notifier.pop();

      i += 1;
      num -= 1;
    }

    return i;
  }

  void deleteResponses() {
    notifier.empty();
  }

private:
    orderentry::Market *market_;
    orderentry::NamedOrderBook &namedBook_;
    std::queue<orderentry::FilledOrder> notifier;

};

class ServerContext : public BasicAppContext {
 public:
  ServerContext(int my_id, std::vector<int> &remote_ids)
#ifdef CONSENSUS
    : consensus(my_id, remote_ids)
#endif
  {
    std::ostream * log = &std::cout;
    market = orderentry::Market(log);
    namedBook = market.createBook("AAPL");

    for (int i = 0; i < tradersNum; i++) {
      traders.emplace_back(&market, namedBook);
    }
  }

  orderentry::Market market;
  orderentry::NamedOrderBook namedBook;
  erpc::Latency latency;
  int index_ts;
  std::vector<TIMESTAMP_T> start_ts;
  std::vector<TIMESTAMP_T> end_ts;

  std::vector<TraderContext> traders;

#ifdef CONSENSUS
  dory::Consensus consensus;
#endif
  int commit_ret;
};

void server_func(erpc::Nexus *nexus) {
  std::vector<size_t> port_vec = flags_get_numa_ports(FLAGS_numa_node);
  uint8_t phy_port = port_vec.at(0);

  // Crash-consensus assumes ids are strictly positive
  std::vector<int> remote_ids;
  int my_id = -1;
  for (std::pair<int, std::string> element : serverURIs) {
    if (URI == element.second) {
      my_id = element.first;
      continue;
    }
    remote_ids.push_back(element.first);
  }

  ServerContext c(my_id, remote_ids);

#ifdef CONSENSUS
  c.consensus.commitHandler([&c](bool leader, uint8_t* buf, size_t len) {
    const auto req = reinterpret_cast<const ClientRequest*>(buf);
    auto &trader = c.traders[req->client_id];
    c.commit_ret = trader.placeOrder(req->req_id, req->is_buy, req->price, req->qty);

    if (!leader) {
      trader.deleteResponses();
    }
  });
#endif

  erpc::Rpc<erpc::CTransport> rpc(nexus, static_cast<void *>(&c), kAppServerRpcId, basic_sm_handler, phy_port);
  c.rpc = &rpc;

  c.index_ts = 0;
  c.start_ts.resize(2*MEDIAN_SAMPLE_SIZE);
  c.end_ts.resize(2*MEDIAN_SAMPLE_SIZE);

  auto &s = c.start_ts;
  auto &e = c.end_ts;

  std::memset(&s[0], 0, sizeof(s[0]) * s.size());
  std::memset(&e[0], 0, sizeof(e[0]) * e.size());

  while (true) {
    rpc.run_event_loop(kAppEvLoopMs);
    // uint32_t remain = uint32_t(c.order_book.bids().size() + c.order_book.asks().size());
    // printf("Remain: %u ; Success count: %zu ; Fail count: %zu\n", remain, c.success_count, c.fail_count);
    // printf("%.1f %.1f %.1f %.1f\n",
    //        c.latency.perc(.5) / kAppLatFac, c.latency.perc(.05) / kAppLatFac,
    //        c.latency.perc(.99) / kAppLatFac, c.latency.perc(.999) / kAppLatFac);

    // c.latency.reset();
    if (ctrl_c_pressed == 1) break;
  }
}

void req_handler(erpc::ReqHandle *req_handle, void *_context) {

  // TIMESTAMP_T start_tsc, end_tsc;
  // GET_TIMESTAMP(start_tsc);
  auto start_tsc = erpc::rdtsc();

  auto *c = static_cast<ServerContext *>(_context);

  const erpc::MsgBuffer *req_msgbuf = req_handle->get_req_msgbuf();
  const auto req = reinterpret_cast<const ClientRequest*>(req_msgbuf->buf);

#ifdef CONSENSUS
  // GET_TIMESTAMP(c->start_ts[c->index_ts]);
  auto err = c->consensus.propose(req_msgbuf->buf, req_msgbuf->get_data_size());
  // GET_TIMESTAMP(c->end_ts[c->index_ts]);
// #ifdef STORE_MEASUREMENTS
//   c->index_ts += 1;
// #endif
#endif

  auto &resp = req_handle->pre_resp_msgbuf;
  auto repl_resp = reinterpret_cast<ReplicationResponse *>(resp.buf);
  repl_resp->cli_resp.offset = cli_resp_offset;

  auto &trader = c->traders[req->client_id];



#ifdef CONSENSUS
  switch (err) {
    case dory::ProposeError::NoError:
      repl_resp->kind = ReplicationResponse::OK;
      repl_resp->v.commit_ret = c->commit_ret;

      if (trader.previousResponsesNum() > 0) {
        auto cli_resp_num = std::min(trader.previousResponsesNum(), max_num_cli_resp);
        c->rpc->resize_msg_buffer(&resp, cli_resp_offset + sizeof(ClientResponse) * cli_resp_num);
        auto cli_resp = reinterpret_cast<ClientResponse *>(uintptr_t(repl_resp) + cli_resp_offset);
        repl_resp->cli_resp.num = trader.copyPreviousResponses(cli_resp_num, cli_resp);
      } else {
        c->rpc->resize_msg_buffer(&resp, sizeof(ReplicationResponse));
        repl_resp->cli_resp.num = 0;
      }
      break;

    case dory::ProposeError::FastPath:
    case dory::ProposeError::FastPathRecyclingTriggered:
    case dory::ProposeError::SlowPathCatchFUO:
    case dory::ProposeError::SlowPathUpdateFollowers:
    case dory::ProposeError::SlowPathCatchProposal:
    case dory::ProposeError::SlowPathUpdateProposal:
    case dory::ProposeError::SlowPathReadRemoteLogs:
    case dory::ProposeError::SlowPathWriteAdoptedValue:
    case dory::ProposeError::SlowPathWriteNewValue:
    case dory::ProposeError::SlowPathLogRecycled:
      c->rpc->resize_msg_buffer(&resp, sizeof(ReplicationResponse));
      repl_resp->kind = ReplicationResponse::FATAL;
      repl_resp->v.fatal_error = static_cast<int>(err);
      break;

    case dory::ProposeError::MutexUnavailable:
    case dory::ProposeError::FollowerMode:
      c->rpc->resize_msg_buffer(&resp, sizeof(ReplicationResponse));
      repl_resp->kind = ReplicationResponse::CHANGE_LEADER;
      repl_resp->v.potential_leader = c->consensus.potentialLeader();
      break;

    default:
      std::cout << "Bug in code. You should only handle errors here"
                << std::endl;
  }
#else
  // GET_TIMESTAMP(c->start_ts[c->index_ts]);
  auto immediately_filled = trader.placeOrder(req->req_id, req->is_buy, req->price, req->qty);
  // GET_TIMESTAMP(c->end_ts[c->index_ts]);

// #ifdef STORE_MEASUREMENTS
//   c->index_ts += 1;
// #endif

  repl_resp->kind = ReplicationResponse::OK;
  repl_resp->v.commit_ret = immediately_filled;

  if (trader.previousResponsesNum() > 0) {
    auto cli_resp_num = std::min(trader.previousResponsesNum(), max_num_cli_resp);
    c->rpc->resize_msg_buffer(&resp, cli_resp_offset + sizeof(ClientResponse) * cli_resp_num);
    auto cli_resp = reinterpret_cast<ClientResponse *>(uintptr_t(repl_resp) + cli_resp_offset);
    repl_resp->cli_resp.num = trader.copyPreviousResponses(cli_resp_num, cli_resp);
  } else {
    c->rpc->resize_msg_buffer(&resp, sizeof(ReplicationResponse));
    repl_resp->cli_resp.num = 0;
  }
#endif

  if (!(c->consensus.blockedResponse())) {
    c->rpc->enqueue_response(req_handle, &req_handle->pre_resp_msgbuf);
  } else {
    std::cout << "Response blocked" << std::endl;
  }

  // double req_lat_us =
  //     erpc::to_usec(erpc::rdtsc() - start_tsc, c->rpc->get_freq_ghz());
  // c->latency.update(static_cast<size_t>(req_lat_us * kAppLatFac));

// // #ifdef CONSENSUS
//   if (c->index_ts == MEDIAN_SAMPLE_SIZE) {
//     std::ofstream dump;
//     dump.open ("dump.txt");

//     std::vector<uint64_t> diffs;
//     for (int i = 0; i < MEDIAN_SAMPLE_SIZE; i++) {
//       auto diff = ELAPSED_NSEC(c->start_ts[i], c->end_ts[i]);
//       dump << diff << "\n";
//     }

//     dump.close();
//     std::cout << "Dumped the data" << std::endl;

//     // std::this_thread::sleep_for(std::chrono::seconds(5));
//     // exit(0);
//   }
// #endif
}