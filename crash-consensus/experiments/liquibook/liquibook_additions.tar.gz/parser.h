#pragma once

#include <sstream>
#include <string>
#include <algorithm>
#include <map>

bool validURI(std::string const &uri) {
  size_t colonPos = uri.find(':');

  if (colonPos != std::string::npos) {
    std::string hostPart = uri.substr(0,colonPos);
    std::string portPart = uri.substr(colonPos+1);

    std::stringstream parser(portPart);

    int port = 0;
    if (parser >> port) {
      return port > 0 && port < 65536;
    }
  }

  return false;
}

// Code taken from master of spdlog. Eventually, when spdlog creates an new
// release, this piece of code will no longer be necessary.

// Copyright(c) 2015-present, Gabi Melman & spdlog contributors.
// Distributed under the MIT License (http://opensource.org/licenses/MIT)

// inplace convert to lowercase
static inline std::string &to_lower_(std::string &str) {
  std::transform(str.begin(), str.end(), str.begin(), [](char ch) {
    return static_cast<char>((ch >= 'A' && ch <= 'Z') ? ch + ('a' - 'A') : ch);
  });
  return str;
}

// inplace trim spaces
static inline std::string &trim_(std::string &str) {
  const char *spaces = " \n\r\t";
  str.erase(str.find_last_not_of(spaces) + 1);
  str.erase(0, str.find_first_not_of(spaces));
  return str;
}

// return (name,value) trimmed pair from given "name=value" string.
// return empty string on missing parts
// "key=val" => ("key", "val")
// " key  =  val " => ("key", "val")
// "key=" => ("key", "")
// "val" => ("", "val")
static inline std::pair<std::string, std::string> extract_kv_(
    char sep, const std::string &str) {
  auto n = str.find(sep);
  std::string k, v;
  if (n == std::string::npos) {
    v = str;
  } else {
    k = str.substr(0, n);
    v = str.substr(n + 1);
  }
  return std::make_pair(trim_(k), trim_(v));
}

// return vector of key/value pairs from sequence of "K1=V1,K2=V2,.."
// "a=AAA,b=BBB,c=CCC,.." => {("a","AAA"),("b","BBB"),("c", "CCC"),...}
static inline std::unordered_map<std::string, std::string> extract_key_vals_(
    const std::string &str) {
  std::string token;
  std::istringstream token_stream(str);
  std::unordered_map<std::string, std::string> rv{};
  while (std::getline(token_stream, token, ',')) {
    if (token.empty()) {
      continue;
    }
    auto kv = extract_kv_('=', token);
    rv[kv.first] = kv.second;
  }
  return rv;
}

static inline std::map<int, std::string> parseServerURIs(const std::string &server_uris) {
  auto key_vals = extract_key_vals_(server_uris);

  if (key_vals.size() == 0) {
    throw std::runtime_error("Invalid data during parsing: empty string");
  }

  std::map<int, std::string> ret;

  for (std::pair<std::string, std::string> element : key_vals) {
    std::stringstream parser(element.first);

    int server_id = 0;
    if (parser >> server_id) {
      if (server_id <= 0) {
        throw std::runtime_error("Invalid data during parsing: negative id.");
      }
    } else {
      throw std::runtime_error("Invalid data during parsing: not a number.");
    }

    if (!validURI(element.second)) {
      throw std::runtime_error("Invalid data during parsing: Bad format.");
    }

    ret.insert(std::make_pair(server_id, element.second));
  }

  return ret;
}
