#include "util/latency.h"
#include <gflags/gflags.h>
#include <signal.h>
#include <cstring>
#include "../apps_common.h"
#include "rpc.h"
#include "util/autorun_helpers.h"
#include "util/numautils.h"

#include "market/Market.h"
#include "book/types.h"
#include "timers.h"

#include "parser.h"

#undef CONSENSUS
#define CONSENSUS

#ifdef CONSENSUS
#include <dory/crash-consensus.hpp>
#endif

#include <sys/types.h>
#include <unistd.h>

#include <chrono>
#include <thread>
#include <iostream>
#include <string>
#include<cstdlib>
#include<ctime>

volatile sig_atomic_t ctrl_c_pressed = 0;
void ctrl_c_handler(int) { ctrl_c_pressed = 1; exit(0); }

std::string URI;
std::map<int, std::string> serverURIs;
int tradersNum, traderID;

static constexpr size_t kAppServerRpcId = 2;  // Rpc ID of all Raft servers
static constexpr size_t kAppClientRpcId = 3;  // Rpc ID of the Raft client

static constexpr size_t kAppEvLoopMs = 3000;  // Duration of event loop
static constexpr bool kAppVerbose = false;    // Print debug info on datapath
static constexpr double kAppLatFac = 10.0;    // Precision factor for latency
static constexpr size_t kAppReqType = 1;      // eRPC request type
static constexpr size_t kChangeLeaderTimeoutNs = 800000;
static constexpr size_t kShortEvLoopUs = 100; // should be at least double kChangeLeaderTimeoutUs

#include "common.h"
#include "server.h"
#include "client.h"


int main(int argc, char **argv) {
  srand(time(0));

  TIMESTAMP_INIT

  std::cout << "Process PID: " << getpid() << std::endl;

  signal(SIGINT, ctrl_c_handler);
  gflags::ParseCommandLineFlags(&argc, &argv, true);

  OperationalMode operationalMode;

  if (const char* mode = std::getenv("MODE")) {
    std::string op_mode(mode);

    if (op_mode == "server") {
      operationalMode = OperationalMode::Server;
    } else if (op_mode == "client") {
      operationalMode = OperationalMode::Client;
    } else {
      throw std::runtime_error("OperationalMode must be either `server` or `client`.");
    }
  } else {
    throw std::runtime_error("Please set the MODE environment variable to either `server` or `client`.");
  }

  if (const char* uri = std::getenv("URI")) {
    URI = std::string(uri);

    if (!validURI(URI)) {
      throw std::runtime_error("Provided URI is not valid.");
    }
  } else {
    throw std::runtime_error("Please set the URI environment variable to `<hostname>:<port>`.");
  }

  if (const char* uri = std::getenv("SERVER_URIS")) {
    std::string URI(uri);
    serverURIs = parseServerURIs(URI);

  } else {
    throw std::runtime_error("Please set the SERVER_URIS environment variable to a comma separated list of `<id>=<hostname>:<port>`.");
  }

  if (operationalMode == OperationalMode::Server) {
    if (const char* traders = std::getenv("TRADERS_NUM")) {
      std::string num(traders);
      tradersNum = std::stoi(traders);

    } else {
      throw std::runtime_error("Please set the TRADERS_NUM environment variable`.");
    }
  }

  if (operationalMode == OperationalMode::Client) {
    if (const char* trader = std::getenv("TRADER_ID")) {
      std::string id(trader);
      traderID = std::stoi(id);

    } else {
      throw std::runtime_error("Please set the TRADER_ID environment variable`.");
    }
  }

  erpc::rt_assert(FLAGS_numa_node <= 1, "Invalid NUMA node");

  erpc::Nexus nexus(URI, FLAGS_numa_node, 0);
  nexus.register_req_func(kAppReqType, req_handler);

  auto t = std::thread(operationalMode == OperationalMode::Server ? server_func : client_func, &nexus);
  erpc::bind_to_core(t, FLAGS_numa_node, 0);
  t.join();
}
